# Qwen / LLaVA unified evaluation entry

This directory copies launcher and input adapters from the named 20261104 releases. It does not alter existing jobs or their results. Use `run.py` to select model, dataset and method. Outputs must have a distinct output directory. `summarize.py OUTPUT_DIR` dispatches by manifest.

Examples (use available GPUs and a new output directory):

```bash
python run.py --benchmark ovobench --model qwen25vl --method sparsemm --gpus 0,1,2,3 --output-dir /path/to/output
python run.py --benchmark ovobench --model llavaov --method hermes --gpus 0,1,2,3 --output-dir /path/to/output
python run.py --benchmark streamingbench --model qwen25vl --method lukv --cohort full --accept-equivalent-choices --allow-calibration-overlap --gpus 0,1,2,3 --output-dir /path/to/output
```

1 fps Qwen: normal area 448^2, latest 896^2, two-frame updates; latest-frame replay changes temporal pairing and is experimental. LLaVA: 384x384, ordinary frame 196 tokens and latest frame 729 tokens. Compression methods average visual budget 500; Full KV uncompressed. Methods and backbones keep their own cache strategies. In StreamingBench full Qwen, one question has duplicate correct choice text: --accept-equivalent-choices scores either correct option. LU-KV uses a profile calibrated on 50 StreamingBench videos, and full cohort overlaps calibration; record this.

EGate is not included in this baseline interface; it has a separate experimental Qwen StreamingBench implementation and its DSCache Qwen input is not yet aligned.

The copied launchers call frozen method implementations, model weights, datasets, assets and runtime directories still stored under `/mnt/aifordata2026-p/common/aifordata/541707`; this is not a standalone portable export. In particular LLaVA launchers depend on `/tmp/llava-ovo-transformers440` and `/tmp/siglip-so400m-patch14-384`. Method implementations and asset paths remain in the original releases; see manifests and the backend source for exact paths and hashes. Existing running tasks continue using their original code.

Control layer updated: see ARCHITECTURE.md. --plan-only prints configuration without backend execution; completed runs record explicit provenance in launcher_plan.json. Legacy Qwen StreamingBench summaries require an explicit --backend. Original root launchers are preserved in legacy_control/.
